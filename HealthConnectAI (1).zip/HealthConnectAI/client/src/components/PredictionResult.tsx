import { useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Circle, InfoIcon, AlertTriangle, Heart, BarChart, FileText, ArrowLeft } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

interface PredictionResultProps {
  result: any;
  onReset: () => void;
}

export default function PredictionResult({ result, onReset }: PredictionResultProps) {
  const explanationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (explanationRef.current) {
      explanationRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, []);

  // Destructure the result
  const { prediction, result: predictionDetails } = result;
  const { prediction: hasHeartDisease, confidence, explanations } = predictionDetails;
  
  // Format the prediction result for chart display
  const chartData = [
    { name: hasHeartDisease ? "High Risk" : "Low Risk", value: confidence },
    { name: hasHeartDisease ? "Low Risk" : "High Risk", value: 100 - confidence }
  ];
  
  // Colors for the chart
  const COLORS = hasHeartDisease ? ["#ef4444", "#3b82f6"] : ["#22c55e", "#3b82f6"];
  
  // Format the explanation data for bar chart
  const explanationData = explanations.map((exp: any) => ({
    name: exp.feature,
    value: exp.value,
    impact: exp.impact
  }));

  return (
    <div className="space-y-8" ref={explanationRef}>
      <Card className="border-2">
        <CardHeader className={`${hasHeartDisease ? "bg-red-50" : "bg-green-50"} rounded-t-lg`}>
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${hasHeartDisease ? "bg-red-100" : "bg-green-100"}`}>
              {hasHeartDisease ? (
                <AlertTriangle className="h-6 w-6 text-red-600" />
              ) : (
                <Heart className="h-6 w-6 text-green-600" />
              )}
            </div>
            <div>
              <CardTitle className={`text-xl ${hasHeartDisease ? "text-red-700" : "text-green-700"}`}>
                {hasHeartDisease ? "Increased Risk Detected" : "Low Risk Detected"}
              </CardTitle>
              <CardDescription>
                {hasHeartDisease
                  ? "Our model detected potential risk factors for heart disease"
                  : "Our model did not detect significant risk factors for heart disease"}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="order-2 md:order-1">
              <h3 className="text-lg font-medium mb-4">Prediction Details</h3>
              
              <div className="space-y-4">
                <div className="p-4 rounded-lg border">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium">Confidence Level</p>
                      <p className="text-2xl font-bold">{confidence}%</p>
                    </div>
                    <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                      hasHeartDisease ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                    }`}>
                      {hasHeartDisease ? confidence : 100 - confidence}%
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">Key Factors</h4>
                  {explanations.map((explanation: any, index: number) => (
                    <div key={index} className="flex items-start gap-3 border-b pb-3">
                      <Circle className="h-2 w-2 mt-2 flex-shrink-0" fill="currentColor" />
                      <div>
                        <p className="font-medium">{explanation.feature}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-sm">Value: {explanation.value}</span>
                          <span className={`px-2 py-0.5 rounded text-xs ${
                            explanation.impact.includes("high") || explanation.impact.includes("elevated") || explanation.impact.includes("concerning")
                              ? "bg-red-100 text-red-700"
                              : explanation.impact.includes("low") || explanation.impact.includes("normal") || explanation.impact.includes("good")
                              ? "bg-green-100 text-green-700"
                              : "bg-yellow-100 text-yellow-700"
                          }`}>
                            {explanation.impact}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="order-1 md:order-2 flex flex-col items-center">
              <h3 className="text-lg font-medium mb-4">Risk Assessment</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      fill="#8884d8"
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="mt-4 text-center w-full max-w-md">
                <p className="text-sm">
                  {hasHeartDisease
                    ? "This prediction indicates potential risk factors for heart disease. Please consult with a healthcare professional for a proper evaluation."
                    : "This prediction indicates low risk for heart disease based on the provided data. Continue maintaining healthy habits."}
                </p>
              </div>
            </div>
          </div>
          
          <Separator className="my-6" />
          
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <BarChart className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-medium">Health Metrics Analysis</h3>
            </div>
            
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ReBarChart
                  data={explanationData}
                  layout="vertical"
                  margin={{ top: 20, right: 30, left: 150, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis 
                    type="category" 
                    dataKey="name" 
                    tick={{ fontSize: 12 }}
                    width={140}
                  />
                  <Tooltip 
                    formatter={(value, name, props) => [value, props.payload.impact]}
                    labelFormatter={(value) => `Feature: ${value}`}
                  />
                  <Bar 
                    dataKey="value" 
                    fill="#3b82f6" 
                    background={{ fill: "#eee" }} 
                  />
                </ReBarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between items-center bg-muted/20 p-6 rounded-b-lg">
          <div className="flex items-center text-sm text-muted-foreground">
            <InfoIcon className="h-4 w-4 mr-2" />
            <p>This is a predictive analysis and should not replace professional medical advice.</p>
          </div>
          <Button onClick={onReset} variant="outline" className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            What Should I Do Next?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {hasHeartDisease ? (
            <>
              <p>
                Based on the analysis, our model detected potential risk factors for heart disease. Here are some recommended next steps:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Consult with your healthcare provider to discuss these results</li>
                <li>Schedule a comprehensive cardiovascular check-up</li>
                <li>Consider lifestyle modifications such as improved diet and regular exercise</li>
                <li>Monitor your blood pressure and cholesterol levels regularly</li>
                <li>Use the messaging feature to contact a cardiologist on our platform</li>
              </ul>
            </>
          ) : (
            <>
              <p>
                Based on the analysis, our model did not detect significant risk factors for heart disease. Here are some recommended next steps:
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Continue maintaining healthy lifestyle habits</li>
                <li>Schedule regular check-ups with your healthcare provider</li>
                <li>Monitor your health metrics periodically</li>
                <li>Stay physically active and maintain a balanced diet</li>
                <li>Consider regular heart health screenings if you have a family history of heart disease</li>
              </ul>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
